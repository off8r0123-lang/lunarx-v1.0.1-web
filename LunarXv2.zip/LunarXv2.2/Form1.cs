﻿using QuorumMonaco;
using RazzAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LunarXv2._2
{
    public partial class Form1 : Form
    {
        private string fileDirectory = Path.Combine(Application.StartupPath, "Scripts");
        public Form1()
        {
            InitializeComponent();
            Comunication.Start();

            {
                ScriptList.Items.Clear();


                if (Directory.Exists(fileDirectory))
                {
                    string[] files = Directory.GetFiles(fileDirectory, ".")
                                              .Where(f => f.EndsWith(".lua") || f.EndsWith(".txt"))
                                              .ToArray();

                    foreach (string file in files)
                    {
                        ScriptList.Items.Add(Path.GetFileName(file));
                    }
                }
                else
                {

                }

            }

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void ScriptList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ScriptList.SelectedItem != null)
            {
                string selectedFile = Path.Combine(fileDirectory, ScriptList.SelectedItem.ToString());

                if (File.Exists(selectedFile))
                {
                    fastColoredTextBox1.Text = File.ReadAllText(selectedFile);
                }
            }

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            RazzAPI.Modules.Inject();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Utilities.KillRoblox();
        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            RazzAPI.Modules.ExecuteScript(fastColoredTextBox1.Text);
        }
    }
    }

